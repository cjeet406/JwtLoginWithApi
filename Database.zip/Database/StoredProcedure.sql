USE [TestingDB]
GO
/****** Object:  StoredProcedure [dbo].[SP_Jeet_Registration]    Script Date: 02-03-2023 14:15:20 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jeet Chauhan
-- Create date: <Create Date,,>
-- Description:	Testing Registration
-- =============================================
ALTER PROCEDURE [dbo].[SP_Jeet_Registration]
	@cmd int = 0,
	@name nvarchar(50) = null,
	@email nvarchar(50) = null,
	@pass nvarchar(50) = null
AS
BEGIN
	if(@cmd = 1)
	begin
		select * from tbl_Jeet_Registration
	end
	if(@cmd = 2)
	begin
		if exists (select * from tbl_Jeet_Registration where email = @email and name = @name)
		begin
			select 'already exists'
		end
		else
		begin
			insert into tbl_Jeet_Registration (name, email, password) values (@name, @email,@pass)
			select 'Registration Successfully.'
		end
	end
	if(@cmd = 3)
	begin
		update tbl_Jeet_Registration set password = @pass where email = @email
	end
	if(@cmd = 4) -- for login
	begin
	declare @loginName nvarchar(500) = null
		select @loginName=name from tbl_Jeet_Registration where email = @email and password = @pass
		if(@loginName is not null)
		begin
			select @loginName
		end
		else
		begin
			select 'Please Register First!'
		end
	end
END
--truncate table tbl_Jeet_Registration
--INSERT INTO tbl_Jeet_Registration (name,password,email) values('jeet','chauhan','cjeet406@gmail.com')
--exec [SP_Jeet_Registration] @cmd = 4,@email = 'cjeet406@gmail.com', @pass = 'chauhan'
