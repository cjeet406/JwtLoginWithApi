﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JWTRegisrationAndLogin.Models
{
    public class Login
    {
        public string emailid { get; set; }
        public string password { get; set; }
    }
}
