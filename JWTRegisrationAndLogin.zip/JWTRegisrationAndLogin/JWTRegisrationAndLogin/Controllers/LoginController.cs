﻿using JWTRegisrationAndLogin.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace JWTRegisrationAndLogin.Controllers
{
    public class LoginController : Controller
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly string Jwt  = string.Empty;
        public LoginController(IHttpClientFactory httpClientFactory)
        {
            this._clientFactory = httpClientFactory;
            this.Jwt = "UserControll";
        }

        public IActionResult LoginUser()
        {
            return View();
        }

        public IActionResult RegistrationUser()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> RegistrationUserData(RegistrationClass registration)
        {
            string apiResponse = "";
            if (ModelState.IsValid)
            {
                StringContent content = new StringContent(JsonConvert.SerializeObject(registration), Encoding.UTF8, "application/json");
                var client = _clientFactory.CreateClient("JWTApi");
                HttpResponseMessage response = await client.PostAsync(Jwt + "/RegistrationProcess", content);

                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    apiResponse = await response.Content.ReadAsStringAsync();
                    if(apiResponse == "Registration Successfully.")
                    {
                        Login lg = new Login();
                        lg.emailid = registration.email;
                        lg.password = registration.password;
                        return await LoginUserData(lg);
                    }
                    else
                    {
                        return RedirectToAction("RegistrationUser", TempData["msg"] = "something went wrong!! while processing.");
                    }
                    //return RedirectToAction("RegistrationUser", TempData["msg"] = apiResponse);
                }
                else
                {
                    return RedirectToAction("RegistrationUser", TempData["msg"] = "something went wrong!!");
                }
            }
            else
            {
                return RedirectToAction("RegistrationUser", TempData["msg"] = "Some input fild is not valid");
            }
        }
        [HttpPost]
        public async Task<IActionResult> LoginUserData(Login login)
        {
            if (ModelState.IsValid)
            {
                string apiResponse = "";
                StringContent content = new StringContent(JsonConvert.SerializeObject(login), Encoding.UTF8, "application/json");
                var client = _clientFactory.CreateClient("JWTApi");
                HttpResponseMessage response = await client.PostAsync(Jwt + "/LoginProcess", content);
                if (response.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    apiResponse = await response.Content.ReadAsStringAsync();
                    return RedirectToAction("GetDetails", "Details", TempData["name"] = apiResponse);
                }
                else
                {
                    return RedirectToAction("LoginUser", TempData["msg"] = "Login Success Fully");
                }
            }
            return Json(new { msg = "Login Successfully" });
        }
    }
}
