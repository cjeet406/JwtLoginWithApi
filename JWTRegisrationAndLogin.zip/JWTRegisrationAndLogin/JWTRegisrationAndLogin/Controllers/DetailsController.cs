﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace JWTRegisrationAndLogin.Controllers
{
    public class DetailsController : Controller
    {
        public IActionResult GetDetails()
        {
            return Json("success fully");
        }
    }
}
