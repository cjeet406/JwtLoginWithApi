﻿using JWTDemo.Model;
using JWTRegisrationAndLogin.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace JWTDemo.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class UserControllController : ControllerBase
    {
        public IConfiguration _config { get; set; }
        public IHttpContextAccessor _httpContextAccessor { get; set; }
        public UserControllController(IConfiguration config,IHttpContextAccessor httpContextAccessor)
        {
            this._config = config;
            this._httpContextAccessor = httpContextAccessor;
        }

      
        

        [HttpPost]
        public IActionResult LoginProcess(Login login)
        {
            string token;
            var isExist = this.CheckTokenIsExistOrNot(login.emailid);
            if (!isExist)
            {
                JwtService jwt = new JwtService(_config);
                token = jwt.GenerateSecurityToken(login.emailid);
                _httpContextAccessor.HttpContext.Session.SetString("token", token);
            }
            else
            {
                token = _httpContextAccessor.HttpContext.Session.GetString("token");
            }
          
            DataLayer.Logics.DBOperations db = new DataLayer.Logics.DBOperations();
            string msg = "";
            SqlCommand cmd = new SqlCommand();
            //cmd.Parameters.AddWithValue("@name", registration.name);
            cmd.Parameters.AddWithValue("@email", login.emailid);
            cmd.Parameters.AddWithValue("@pass", login.password);
            cmd.Parameters.AddWithValue("@cmd", 4);
            var msg1 = db.Sp_Execute("TestingDB.dbo.SP_Jeet_Registration", cmd);
            
            SqlCommand cmd2 = new SqlCommand();
            cmd2.Parameters.AddWithValue("@cmd", 2);
            cmd2.Parameters.AddWithValue("@token", token);
            cmd2.Parameters.AddWithValue("@userid", login.emailid);
            var tokenMsg = db.Sp_Execute("TestingDB.dbo.SP_LoginTraking_With_Token", cmd2);
            if (tokenMsg != null)
            {
                if (tokenMsg.ToString() != token)
                {
                    return BadRequest(new { msg = "token is not valid" });
                }
                else
                {
                    return Ok("Token Match");
                }
                
            }
            else
            {
                var obj = new
                {
                    msg1 = msg1,
                    token = token
                };
                return Ok(obj);
            }
           
        }
        [HttpPost]
        public IActionResult RegistrationProcess(RegistrationClass registration)
        {
            DataLayer.Logics.DBOperations db = new DataLayer.Logics.DBOperations();
            string msg = "";
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@name", registration.name);
            cmd.Parameters.AddWithValue("@email", registration.email);
            cmd.Parameters.AddWithValue("@pass", registration.password);
            cmd.Parameters.AddWithValue("@cmd", 2);
            var msg1 = db.Sp_Execute("TestingDB.dbo.SP_Jeet_Registration", cmd);
            return Ok(msg1);
        }

        public bool CheckTokenIsExistOrNot(string email)
        {
            DataLayer.Logics.DBOperations db = new DataLayer.Logics.DBOperations();
            var createdTken = _httpContextAccessor.HttpContext.Session.GetString("token");
            SqlDataReader reader;
            //var token = reader.IsDBNull;
            if (!string.IsNullOrEmpty(createdTken))
            {
                var token = db.ExecuteStringQuery($"select token from TestingDB.dbo.tbl_LoginTraking_With_Token where token='{createdTken}' and userid = '{email}'");
                if (token != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
           
            return false;
        }
    }
}
