﻿using JWTDemo.Model;
using JWTRegisrationAndLogin.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace JWTDemo.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class USerController : ControllerBase
    {

        private IConfiguration _config;

        public USerController(IConfiguration config)
        {
            _config = config;
        }

        [HttpPost]
        public IActionResult Login(Login Login)
        {
            object obj = GetRandomToken(Login);
            return Ok(obj);
        }
        [HttpGet]
        public object GetRandomToken(Login Login)
        {
            var emailid = Login.emailid;
            var jwt = new JwtService(_config);
            var token = jwt.GenerateSecurityToken(emailid);
            //var refreshToken = this.GenerateRefreshToken();
            //return token + ", 2 :- " + refreshToken;
            return new { id = token, email = emailid };
        }

    }
}
//public class Login
//{
//    public string EmailID { get; set; }
//    public string Password { get; set; }
//}
